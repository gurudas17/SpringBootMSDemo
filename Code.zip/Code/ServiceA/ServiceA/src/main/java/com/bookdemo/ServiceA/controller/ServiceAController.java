package com.bookdemo.ServiceA.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bookdemo.ServiceA.Entity.Book;
import com.bookdemo.ServiceA.service.BookService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class ServiceAController {
	// final static Logger logger = LoggerFactory.getLogger(ServiceAController.class);

	@Autowired
	BookService bookServ;

	@GetMapping("/")
	public List<Book> getAllBooks() {
		log.debug( "getAllBooks method call ");
		return bookServ.getAllBooks();
	}

	@GetMapping("/{id}")
	public ResponseEntity<Book> getBookbyId(@PathVariable("id") int id) {
		Optional<Book> optBook = Optional.ofNullable(bookServ.getBookbyId(id));
		if (optBook.isPresent())
			return new ResponseEntity<>((Book) optBook.get(), HttpStatus.OK);
		else
			return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
	}

	@PostMapping("/")
	public ResponseEntity<String> addBook(@RequestBody Book b) {
		if (bookServ.addBook(b))
			return new ResponseEntity<>("Book Added Sucessfully", HttpStatus.OK);
		else
			return new ResponseEntity<>("Parameters are wrong or Technical Issue occur", HttpStatus.BAD_REQUEST);
	}

}
