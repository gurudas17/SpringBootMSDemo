package com.bookdemo.ServiceB.exception;

public class BookNotFoundException extends Exception{
	

}
