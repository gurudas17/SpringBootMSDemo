package com.bookdemo.ServiceB.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bookdemo.ServiceB.Entity.Book;
import com.bookdemo.ServiceB.service.BookService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping ("/Books")
public class ServiceBController {
	
	@Autowired
	BookService bookServ; 
	
	@GetMapping("/")
	public List<Book> getAllBooks ()
	{
		log.debug(" In ServiceBController:: getAllBooks ( )");
		return bookServ.getAllBooks();
	}

	@GetMapping("/{id}")
	public Book getBookbyId (@PathVariable  ("id") int id)
	{
		log.debug(" In ServiceBController:: getBookbyId ( ) for id "+id);
		Optional<Book> book = 	bookServ.getBookById(id);
		
		if(book.isPresent())
			return (Book) book.get();
		else
			return null;
	}
	
	

		

	@PostMapping("/")
	public boolean addBook (@RequestBody Book b)
	{
		log.debug(" In ServiceBController:: addBook ( ) for book");
			return bookServ.addBook(b);
	}
	
	

}
